package stepDefinations;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Authenticator;
import java.net.HttpURLConnection;
import java.net.PasswordAuthentication;
import java.net.URL;
import java.net.URLConnection;
import java.security.GeneralSecurityException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.log4j.Logger;
//import org.apache.tools.ant.taskdefs.Sleep;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.runner.RunWith;
import org.openqa.selenium.NotFoundException;

//import com.executionClass.ExecutionMenu;
import com.fasterxml.jackson.databind.ObjectMapper;
//import com.webservice.stepDefinations.WebServicesStubs;
//import com.webservice.utilities.XMLFileHandler;

/**
 * API.java
 * 
 * @Purpose API calls
 *
 */


public class SecuredAPI {
//	EncryptFileData encryptFile = new EncryptFileData();
	public Properties nodeMappingProp = new Properties();
	ObjectMapper objMapper = new ObjectMapper();
//	public String apiCallType = ExecutionMenu.systemConfig.getProperty("APICallType");
	//public String authToken = WebServicesStubs.properties.getProperty("Authentication");
	public static Logger logger = Logger.getLogger(SecuredAPI.class);
	public static Map<String, String> serviceResponse = new HashMap<String, String>();
	public static String responseXml;
	public static String sFlagContentHeader = "";
	public static String TokenUser = "";
	public static Process process;
	public static int oamCount=0;
	public static URLConnection writeDataToHttpConnection(URLConnection connection)
			throws IOException {
		
		//@SuppressWarnings("resource")
		//String requestBody = sbuilder.toString();
		//requestBody = (new XMLFileHandler()).replaceJSON(requestBody);
//		ObjectMapper mapper = new ObjectMapper();
//		logger.info("formatted JSON String \n" + (mapper.writerWithDefaultPrettyPrinter()
//				.writeValueAsString(mapper.readValue(requestBody, Object.class))));
//		OutputStreamWriter outputStreamWriter = new OutputStreamWriter(connection.getOutputStream());
//		outputStreamWriter.write(requestBody);
//		outputStreamWriter.flush();
//		outputStreamWriter.close();

		return connection;
	}

}