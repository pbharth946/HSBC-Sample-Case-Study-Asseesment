package stepDefinations;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.runner.RunWith;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.junit.Cucumber;

@RunWith(Cucumber.class)
public class stepDefination {
	URLConnection connection = null;
	Boolean checkHeaders = false;
	String endPointUrl = null;
	URL url=null;
	@Given("^Rates API for Latest Foreign Exchange rates$")
    public void user_is_on_netbanking_landing_page() throws Throwable {
		System.out.println("Get the latest foreign exchange reference rates.");
        
    }
 
	//  @And("^Cards are displayed \"([^\"]*)\"$")
	@When("The API is available \"([^\"]*)\"$")
	public void the_API_is_available(String strArg2)  throws Throwable {
    	
    	endPointUrl=strArg2;
    	url = new URL(strArg2); 
    	
     	if(strArg2=="https://api.ratesapi.io/api/latest"){
     		System.out.println("Connected to :"+strArg2);
    	}
		
    }

    @And("^user provides the required values$")
   	public void validValues(DataTable inputValues) throws Throwable {
   		
   		List<List<String>> getAllValues = inputValues.asLists();
   		
   		for (int i = 1; i < getAllValues.size(); i++) {
   			String parameterName = getAllValues.get(i).get(0);
   			String parameterValue = getAllValues.get(i).get(2);
   			if(parameterName.equalsIgnoreCase("symbols"))
   			{
   				url=new URL(endPointUrl+"?symbols="+parameterValue); 
   			}else if(parameterName.equalsIgnoreCase("base")) {
   				url=new URL(endPointUrl+"?base="+parameterValue); 
			}
   		
   		}
   	}

   
    
    @Then("^user should get the below values in response$")
	public void verifyExpectedValuesWithactualValues(DataTable expectedValues) throws Throwable {
    	connection = (HttpURLConnection) url.openConnection();
		connection.setDoInput(true);
		connection.setDoOutput(true);
		connection.setUseCaches(true);
		try {
			connection.connect();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.print(e);
		}
		connection.setConnectTimeout(30000); // Timeout 30 seconds
		Map<String, List<String>> allHeaders = connection.getHeaderFields();
		System.out.println("All keys are -> " + allHeaders.keySet());
		if (allHeaders.size() > 0) {
			for (String str : allHeaders.keySet()) {
//				logger.info("All headers are -> " + str + ": " + allHeaders.get(str));
				System.out.println(allHeaders.get(str).toString());
			}
		}
		
		List<List<String>> getAllValues = expectedValues.asLists(String.class);
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();
		
		Map<String, String> resultValues = new HashMap<String, String>();
		if(getAllValues.get(0).get(0).equalsIgnoreCase("header")){
				checkHeaders = true;
		}
			for (int i = 1; i < getAllValues.size(); i++) {
				String tagName = getAllValues.get(i).get(0);
				String tagValue = getAllValues.get(i).get(2);
				resultValues.put(tagName, tagValue);
			}
			list.add(resultValues);
		
		System.out.println(resultValues);
		
    }

    @Then("^user should executes with the values$")
   	public void usershouldexecuteswiththevalues() throws Throwable {
       	connection = (HttpURLConnection) url.openConnection();
   		connection.setDoInput(true);
   		connection.setDoOutput(true);
   		connection.setUseCaches(true);
   		try {
   			connection.connect();
   		} catch (IOException e) {
   			// TODO Auto-generated catch block
   			System.out.print(e);
   		}
   		connection.setConnectTimeout(30000); // Timeout 30 seconds
   		Map<String, List<String>> allHeaders = connection.getHeaderFields();
   		System.out.println("All keys are -> " + allHeaders.keySet());
   		if (allHeaders.size() > 0) {
   			for (String str : allHeaders.keySet()) {
//   				logger.info("All headers are -> " + str + ": " + allHeaders.get(str));
   				System.out.println(allHeaders.get(str).toString());
   			}
   		}
   		
   		
       }
    
    
    @Given("^Rates API for Specific date Foreign Exchange rates$")
    public void user_is_on_netbanking_landing_page1() throws Throwable {
		System.out.println("Rates API for Specific date Foreign Exchange rates");
        
    }

}

	

    